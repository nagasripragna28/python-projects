import streamlit as st
import smtplib

class MatchTicketAnalysis:
    def __init__(self):
        self.matches = {
            'cricket': [
                {'venue': 'Stadium 1', 'time': '10:00 AM', 'teams': ['Team A', 'Team B'], 'premium': 50, 'platinum': 100, 'golden': 150, 'silver': 200},
                {'venue': 'Stadium 2', 'time': '2:00 PM', 'teams': ['Team C', 'Team D'], 'premium': 30, 'platinum': 80, 'golden': 120, 'silver': 150}
            ],
            'football': [
                {'venue': 'Stadium X', 'time': '1:00 PM', 'teams': ['Team X', 'Team Y'], 'premium': 20, 'platinum': 60, 'golden': 100, 'silver': 150},
                {'venue': 'Stadium Y', 'time': '4:00 PM', 'teams': ['Team Z', 'Team W'], 'premium': 40, 'platinum': 80, 'golden': 120, 'silver': 200}
            ]
        }
        self.user_details = {}

    def get_user_details(self):
        st.write("Enter your details:")
        self.user_details['name'] = st.text_input("Name:")
        self.user_details['phone'] = st.text_input("Phone Number:")
        self.user_details['email'] = st.text_input("Email Address:")

    def select_sport(self):
        st.write("Select a sport:")
        choice = st.radio("", ["Cricket", "Football"])
        if choice == "Cricket":
            return 'cricket'
        elif choice == "Football":
            return 'football'

    def display_upcoming_matches(self, sport):
        st.write("\nUpcoming Matches:")
        for match in self.matches[sport]:
            st.write("Venue:", match['venue'])
            st.write("Time:", match['time'])
            st.write("Teams:", " vs ".join(match['teams']))
            st.write("Premium Seats:", match['premium'])
            st.write("Platinum Seats:", match['platinum'])
            st.write("Golden Seats:", match['golden'])
            st.write("Silver Seats:", match['silver'])
            st.write()

    def book_seats(self, sport):
        st.write("\nBook Seats:")
        chosen_seat = st.selectbox("Select Seat Type:", ["Premium", "Platinum", "Golden", "Silver"])
        num_seats = st.number_input("Enter the number of seats required:", min_value=1)
        if num_seats <= self.matches[sport][0][chosen_seat.lower()]:
            self.matches[sport][0][chosen_seat.lower()] -= num_seats
            st.write("Seats booked successfully!")
        else:
            st.write("Sorry, the requested number of seats are not available.")

    def select_payment_method(self):
        st.write("\nSelect Payment Method:")
        return st.radio("", ["Credit Card", "Debit Card", "UPI"])

    def send_confirmation_message(self):
        recipient = self.user_details['email']  # You can also use phone number here if needed
        message = f"Hello {self.user_details['name']},\n\nYour ticket details: [Details here]\n\nThank you for booking with us!"
        # This is a hypothetical function to send confirmation messages via email or SMS
        # You need to replace this with actual implementation using an email or SMS API
        sender_email = "your_email@gmail.com"
        sender_password = "your_password"
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, recipient, message)
        server.quit()
        st.write("Confirmation message sent to", recipient)

# Main program
def main():
    ticket_analysis = MatchTicketAnalysis()
    ticket_analysis.get_user_details()
    sport = ticket_analysis.select_sport()
    ticket_analysis.display_upcoming_matches(sport)
    ticket_analysis.book_seats(sport)
    payment_method = ticket_analysis.select_payment_method()
    # You can add further processing or payment integration here
    ticket_analysis.send_confirmation_message()

if __name__ == "__main__":
    main()